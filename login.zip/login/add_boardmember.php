<?php require_once('includes/session.php');
require_once('includes/config.php');
require_once('includes/database.php');
require_once('includes/database_object.php');
require_once('includes/functions.php');
require_once('includes/user.php');
require_once('includes/kalosuchi.php');
require_once('includes/boardmember.php');
require_once('includes/loancom.php');
require_once('includes/financecom.php');
if(isset($_POST['add']))
{
	switch ($_POST['add_name']) {
		case 'boardmember':
				$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
				$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG',);
				if(in_array($ext,$allowed_ext))
				{
					
					$name = randname($_FILES['pic']['name']);
					
					move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/boardmember/".$name);
				}
				$boardmember = new Boardmember();
				$boardmember->firstname = $_POST['firstname'];
				$boardmember->lastname = $_POST['lastname'];
				$boardmember->address = $_POST['address'];
				$boardmember->contact_no = $_POST['contact_no'];
				$boardmember->email = $_POST['email'];
				$boardmember->designation = $_POST['designation'];
				$boardmember->pic_location = $name;
				$boardmember->uploaded_by = $_SESSION['auth_id'];
				if($boardmember->save())
				{
					$session->message("Board Member Added Successfully");
					redirect_to("boardmembers_list.php");
				}
			break;
		case 'loan':
				$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
				$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG',);
				if(in_array($ext,$allowed_ext))
				{
					
					$name = randname($_FILES['pic']['name']);
					
					move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/loan/".$name);
				}
				$loancom = new Loancom();
				$loancom->firstname = $_POST['firstname'];
				$loancom->lastname = $_POST['lastname'];
				$loancom->address = $_POST['address'];
				$loancom->contact_no = $_POST['contact_no'];
				$loancom->email = $_POST['email'];
				$loancom->designation = $_POST['designation'];
				$loancom->pic_location = $name;
				$loancom->uploaded_by = $_SESSION['auth_id'];
				if($loancom->save())
				{
					$session->message("Loan Committee Member Added Successfully");
					redirect_to("loancom_list.php");
				}
			break;
			case 'finance':
				$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
				$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG',);
				if(in_array($ext,$allowed_ext))
				{
					
					$name = randname($_FILES['pic']['name']);
					
					move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/finance/".$name);
				}
				$financecom = new Financecom();
				$financecom->firstname = $_POST['firstname'];
				$financecom->lastname = $_POST['lastname'];
				$financecom->address = $_POST['address'];
				$financecom->contact_no = $_POST['contact_no'];
				$financecom->email = $_POST['email'];
				$financecom->designation = $_POST['designation'];
				$financecom->pic_location = $name;
				$financecom->uploaded_by = $_SESSION['auth_id'];
				if($financecom->save())
				{
					$session->message("Finance Committee Member Added Successfully");
					redirect_to("financecom_list.php");
				}
			break;
		
	}
	
}
elseif(isset($_POST['edit']))
{
	switch ($_POST['add_name']) {
		case 'boardmember':
			$boardmember = Boardmember::find_by_id($_POST['id']);
			if(!empty($_FILES['pic']))
			{
				$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
				$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG',);
				if(in_array($ext,$allowed_ext))
				{
					
					$name = randname($_FILES['pic']['name']);
					if(file_exists("uploaded/boardmember/".$boardmember->pic_location))
					{
						unlink("uploaded/boardmember/".$boardmember->pic_location);
					}
					$boardmember->pic_location = $name;
					move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/boardmember/".$name);
				}
			}
			$boardmember->firstname = $_POST['firstname'];
			$boardmember->lastname = $_POST['lastname'];
			$boardmember->address = $_POST['address'];
			$boardmember->contact_no = $_POST['contact_no'];
			$boardmember->email = $_POST['email'];
			$boardmember->designation = $_POST['designation'];
			//$boardmember->pic_location = $name;
			//$boardmember->uploaded_by = $_SESSION['auth_id'];
			if($boardmember->save())
			{
				$session->message("Board Member Updated Successfully");
				redirect_to("boardmembers_list.php");
			}
			break;

		case 'loan':
			$loancom = Loancom::find_by_id($_POST['id']);
			if(!empty($_FILES['pic']))
			{
				$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
				$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG',);
				if(in_array($ext,$allowed_ext))
				{
					
					$name = randname($_FILES['pic']['name']);
					if(file_exists("uploaded/loan/".$loancom->pic_location))
					{
						unlink("uploaded/loan/".$loancom->pic_location);
					}
					$loancom->pic_location = $name;
					move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/loan/".$name);
				}
			}
			$loancom->firstname = $_POST['firstname'];
			$loancom->lastname = $_POST['lastname'];
			$loancom->address = $_POST['address'];
			$loancom->contact_no = $_POST['contact_no'];
			$loancom->email = $_POST['email'];
			$loancom->designation = $_POST['designation'];
			//$boardmember->pic_location = $name;
			//$boardmember->uploaded_by = $_SESSION['auth_id'];
			if($loancom->save())
			{
				$session->message("Loan Committee Member Updated Successfully");
				redirect_to("loancom_list.php");
			}
			break;

			case 'finance':
			$financecom = Financecom::find_by_id($_POST['id']);
			if(!empty($_FILES['pic']))
			{
				$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
				$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG',);
				if(in_array($ext,$allowed_ext))
				{
					
					
					$name = randname($_FILES['pic']['name']);
					if(file_exists("uploaded/loan/".$loancom->pic_location))
					{
						unlink("uploaded/loan/".$loancom->pic_location);
					}
					$financecom->pic_location = $name;
					move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/finance/".$name);
				}
			}
			$financecom->firstname = $_POST['firstname'];
			$financecom->lastname = $_POST['lastname'];
			$financecom->address = $_POST['address'];
			$financecom->contact_no = $_POST['contact_no'];
			$financecom->email = $_POST['email'];
			$financecom->designation = $_POST['designation'];
			//$boardmember->pic_location = $name;
			//$boardmember->uploaded_by = $_SESSION['auth_id'];
			if($financecom->save())
			{
				$session->message("Finance Committee Member Updated Successfully");
				redirect_to("financecom_list.php");
			}
			break;
		
	}
	
}
else
{
	redirect_to("boardmembers_list.php");
}
?>