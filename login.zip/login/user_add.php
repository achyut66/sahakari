<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
?>
<?php
  if(isset($_POST['add']))
  {
    $user = new User();
    if(!empty($_FILES['pic']))
    {
      $ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
      $allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG','bmp','BMP');
      if(in_array($ext,$allowed_ext))
      {
        
        $name = randname($_FILES['pic']['name']);
        $user->pic_location = $name;
        move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/logo/".$name);
      }
    }
    $user->org_name = $_POST['org_name'];
    $user->fullname = $_POST['fullname'];
    $user->email = $_POST['email'];
    $user->mobile = $_POST['mobile'];
    $user->phone = $_POST['phone'];
    $user->address = $_POST['address'];
    $user->country = $_POST['country'];
    $user->mode = "user";
    $user->password = md5($_POST['password']);
    $user->enable = 1;
    $user->created_date = date("Y-m-d",time());
    $user->save();
    $body = newRegEmail($_POST['email'],$_POST['password']);
    mailto(trim($_POST['email']), "Your Account has been created with SES", $body);
    $session->message("User Saved and Email Sent Successfully");
    redirect_to("users.php");
  }
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Add New User</h2>
									</header>
                                    <div class="irdform">
                                    <span><?=$message?></span>
                                    <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">

                                    	<table class="table">
                                          <tr>
                                              <td>Upload a Logo</td>
                                              <td><input type="file" name="pic"></td>

                                          </tr>
                                          <tr>
                                            <td>Name of Organization</td>
                                            <td><input type="text"  name="org_name" required /></td>
                                          </tr>
                                         
                                          
                                          <tr>
                                            <td>Organization Address</td>
                                            <td><input type="text" name="address" /></td>
                                          </tr>
                                          <tr>
                                            <td>Country</td>
                                            <td><input type="text" name="country" value="Nepal" /></td>
                                          </tr>
                                          <tr>
                                            <td>Mobile Number</td>
                                            <td><input type="text" name="mobile" /></td>
                                          </tr>
                                          <tr>
                                            <td>Landline Number</td>
                                            <td><input type="text" name="phone" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Email</td>
                                            <td><input type="text" name="email" required /></td>
                                          </tr>
                                           <tr>
                                            <td>Contact Person</td>
                                            <td><input type="text" name="fullname" required></td>
                                          </tr>
                                           <tr>
                                            <td>Password</td>
                                            <td><input type="password" name="password" id="password"  required /></td>
                                          </tr>
                                           <tr>
                                            <td>Confirm Password</td>
                                            <td><input type="password" name="confirm_password" id="confirm_password" required /><span id="check_password"></span></td>
                                          </tr>
                                          <tr>
                                            <td>&nbsp;</td>
                                            <td><input type="submit" name="add" value="Add" /></td>
                                          </tr>
                                        </table>

                                    </form>
                                    </div>
									
								</section>

							

						</div>
					</div>

				
        <!-- Sidebar -->
          <div id="sidebar">
            <div class="inner">

              <!-- Search -->
                <div id="irdlogo">
                                 
                  <h3>Sahakari Easy System<br>
                  Nepal</h3>
                                </div>
                               

              <!-- Menu -->
              <?php require_once("menuincludes/menu.php"); ?>

              <!-- Section -->
                
              <!-- Footer -->
                <footer id="footer">
                  <p class="copyright">&copy; 2017. Blacklist Management Morang. All rights reserved. Developed By: <a href="https://pdmt.com.np" title="Purwanchal Digital Media Technologies Pvt. Ltd." target="_blank">PDMT</a></p>
                </footer>

            </div>
          </div>

      </div>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/skel.min.js"></script>
      <script src="assets/js/util.js"></script>
      <!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
      <script src="assets/js/main.js"></script>

  </body>
</html>