var JQ = jQuery.noConflict();
JQ(document).ready(function(){
	JQ(document).on("click","#edititem",function() {
	 	var column_name = JQ(this).attr('name');
		JQ('.edit_item').show();
	 	
    });
     JQ(document).on("click","#check_cit_fields",function() {
        
        var ele = JQ('#check_cit_fields');
        if(ele.is(':checked'))
        {
            JQ('.issued_spouse').show();
            JQ('.issued_father').hide();
        }
        else
        {
            JQ('.issued_spouse').hide();
            JQ('.issued_father').show();
        }
        return false;
    });
    JQ(document).on("keyup","#confirm_password",function() {
        var password = JQ('#password').val();
        var confirm_password = JQ('#confirm_password').val();
        if(confirm_password==="")
        {
            JQ('#check_password').html("");
        }
        else
        {
           if(password===confirm_password)
            {
                var html = '<img src="images/right.png" width="32px" height="32px">';
                JQ('#check_password').html(html);
            }
            else
            {
               var html = '<img src="images/wrong.png" width="32px" height="32px">';
               JQ('#check_password').html(html);
            }
        }
    });
	JQ(document).on("click","#save_rate",function() {
		var pure_gold = JQ('#pure_gold').val();
		var gold_twentyfour = JQ('#gold_twentyfour').val();
		var gold_twentytwo = JQ('#gold_twentytwo').val();
		var silver = JQ('#silver').val();
	 	 //alert(column_name); false;
         

		var param = {};
		param.pure_gold = pure_gold;
		param.gold_twentyfour = gold_twentyfour;
		param.gold_twentytwo = gold_twentytwo;
		param.silver = silver;
		
		JQ.post('saverate.php',param,function(res){
				var obj = JSON.parse(res);
				alert(obj.msg);
			});
    });
	JQ(document).on("click","#saveitem",function() {
	 	var column_name = JQ(this).attr('name');
	 	 //alert(column_name); false;
        
        var bitem_name = JQ('#bitem_name').val();
        var bitem_weight = JQ('#bitem_weight').val();
		var bitem_carat = JQ('#bitem_carat').val();
		var bitem_quantity = JQ('#bitem_quantity').val();
		var bitem_desc = JQ('#bitem_desc').val();
		

		var param = {};
		param.column_name =column_name;
		param.bitem_name =bitem_name;
		param.bitem_weight = bitem_weight;
		param.bitem_carat =bitem_carat;
		param.bitem_quantity = bitem_quantity;
		param.bitem_desc = bitem_desc;
		
		JQ.post('updateitem.php',param,function(res){
				JQ('#bitem_name_edited').html(bitem_name);
				JQ('#bitem_weight_edited').html(bitem_weight);
				JQ('#bitem_carat_edited').html(bitem_carat);
				JQ('#bitem_quantity_edited').html(bitem_quantity);
				JQ('#bitem_desc_edited').html(bitem_desc);
				JQ('.edit_item').hide();
				var obj = JSON.parse(res);
				alert(obj.msg);
			});
    });
	JQ(document).on("click",".updateOnClick",function() {
	 	var column_name = JQ(this).attr('name');
	 	 //alert(column_name); false;
         if(column_name=='corresauthors'){
         var texts= $(".test .text-field").map(function() {
           return $(this).val();
        }).get();
        }
        var column_value = JQ(column_name).val();
        //alert(column_value); false;

		var param = {};
		param.option='com_manuscript';
		
		param.task = 'updateType';
		
		param.column_name =column_name;
		
		param.column_value = column_value;
		
		JQ.post('index.php',param,function(res){
				var obj = JSON.parse(res);
				alert(obj.msg);
			});
    });
    JQ(document).on("click",".calculate_interest",function() {

        var id = JQ(this).attr('name');
        var end_date = JQ("#end_date_"+id).val();
       
        var param = {};
        param.bandaki_id =id;
        param.end_date = end_date;
        JQ.post('calculate_interest.php',param,function(res){
               var obj = JSON.parse(res);
               JQ('#interest_amount_'+id).val(obj.interest_amount);
               
              // alert(obj.interest_amount);
            });
    });
    JQ(document).on("click",".addOnClick",function() {
        var param = {};
        param.option='com_manuscript';
        param.task = 'checkCorresAuthor';
        
        JQ.post('index.php',param,function(res){
                var obj = JSON.parse(res);
                var html = obj.msg;
                  JQ("#corresauthors").append(html);
                    false;
            });
        //var html = '<input type="text" name="corresauthor1" placeholder="title name affiliation"/> <button name="removeOnClick">Remove</button>';
      
    });
    JQ(document).on("click",".descblock",function() {
    	var textblock = JQ(this).attr('name');
    	var styleval = JQ(textblock).css('display');
    	if(styleval =="block"){
    		JQ(textblock).hide();
    	}
    	else{
    		JQ(textblock).show();	
    	}
    	//alert(styleval); false;
    });

    JQ("#uploadOnClick").on("click", function() {
    	//alert("here uplaod"); false;
        var uploadfile = JQ('#upload')[0].files[0];
          //alert(uploadfile); false; 
    //var form_data = new FormData(file_data);                  
    //form_data.append("file", file_data);
    //var data = {

    //	option: 'com_manuscript',
    //	task: 'uploadImage',
    //	form_data: form_data
    //};
    //alert(form_data);   false;                          
    	var param = {};
        param.option = 'com_manuscript';
        param.task = 'uploadImage';
        param.uploadfile = uploadfile;
		//param.tmp_name = tmp_name;
		 JQ.post('index.php',param,function(res){
               
                alert(res);
            });
	});
});