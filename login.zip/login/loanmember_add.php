<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/loanmember.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
?>
  <?php
  set_time_limit(5000);
  ini_set('memory_limit','512M');
  set_include_path(get_include_path() . PATH_SEPARATOR . 'Classes/');
  include 'PHPExcel/IOFactory.php';
  if(isset($_POST['upload_excel']))
  {
    $filename=$_FILES["excel_file"]["tmp_name"];
      move_uploaded_file($filename, "uploads/".$_FILES['excel_file']['name']);
      $inputFileName = "uploads/".$_FILES['excel_file']['name'];
          $objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
          $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
      $arrayCount = count($allDataInSheet);  // Here get total count of row in that Excel sheet

      for($i=2;$i<=$arrayCount;$i++){
      $loanmember = new LoanMember(); 
      $loanmember->name = trim($allDataInSheet[$i]["A"]);
      $loanmember->address = trim($allDataInSheet[$i]["B"]);
      $loanmember->temp_address = trim($allDataInSheet[$i]["C"]);
      
      $loanmember->citizenship_no = trim($allDataInSheet[$i]["D"]);
      
      $loanmember->citizenship_issued_district = trim($allDataInSheet[$i]["E"]);
      $loanmember->issued_date = trim($allDataInSheet[$i]["F"]);
      $loanmember->contact_no = trim($allDataInSheet[$i]["G"]);
      $loanmember->nominee = trim($allDataInSheet[$i]["H"]);
      $loanmember->uploaded_by = $_SESSION['auth_id'];
      $loanmember->save();
      $session->message("Loan Members Added Successfully");
      redirect_to("loanmember_add.php");
      }
      
      
  }
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Add Loan Member</h2>
                    <h4><?=$message?></h4>
									</header>
                                    <div class="irdform">
                                    <form method="post" action="add_loanmember.php" enctype="multipart/form-data">
                                    	<table class="table">
                                         
                                          <tr>
                                            <td>Name</td>
                                            <td><input type="text" name="name" placeholder="Full Name" size="100px" required></td>
                                          </tr>
                                          <tr>
                                            <td>Permanent Address</td>
                                            <td><input type="text" name="address" /></td>
                                          </tr>
                                          <tr>
                                            <td>Temporary Address</td>
                                            <td><input type="text" name="temp_address" /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>CitizenShip Number</td>
                                            <td><input type="text" name="citizenship_no" required /></td>
                                          </tr>
                                          <tr>
                                            <td>CitizenShip Issued From</td>
                                            <td><input list="districts" type="text" name="citizenship_issued_district" required /></td>
                                            <!-- Data list starts -->
                                              <datalist id="districts">
                                                <option value="Bhaktapur">
                                                <option value="Dhading">
                                                <option value="Kathmandu">
                                                <option value="Kavrepalanchok">
                                                <option value="Lalitpur">
                                                <option value="Nuwakot">
                                                <option value="Rasuwa">
                                                <option value="Sindhupalchok">
                                                <option value="Banke">
                                                <option value="Bardiya">
                                                <option value="Dailekh">
                                                <option value="Jajarkot">
                                                <option value="Surkhet">
                                                <option value="Baglung">
                                                <option value="Mustang">
                                                <option value="Myagdi">
                                                <option value="Parbat">
                                                <option value="Gorkha">
                                                <option value="Kaski">
                                                <option value="Lajung ">
                                                <option value="Manang">
                                                <option value="Syangja">
                                                <option value="Tanahu">
                                                <option value="Dhanusa">
                                                <option value="Dolakha">
                                                <option value="Mahottari">
                                                <option value="Ramechhap">
                                                <option value="Sarlahi">
                                                <option value="Sindhuli">
                                                <option value="Dolpa">
                                                <option value="Humla">
                                                <option value="Jumla">
                                                <option value="Kalikot">
                                                <option value="Mugu">
                                                <option value="Bhojpur">
                                                <option value="Dhankuta">
                                                <option value="Morang">
                                                <option value="Sankhuwasabha">
                                                <option value="Sunsari">
                                                <option value="Terhathum">
                                                <option value="Arghakhanchi">
                                                <option value="Gulmi">
                                                <option value="Kapilvastu">
                                                <option value="Nawalparasi">
                                                <option value="Palpa">
                                                <option value="Rupandehi">
                                                <option value="Baitadi">
                                                <option value="Dadeldhura">
                                                <option value="Darchula">
                                                <option value="Kanchanpur">
                                                <option value="Ilam">
                                                <option value="Jhapa">
                                                <option value="Panchthar">
                                                <option value="Taplejung">
                                                <option value="Bara">
                                                <option value="Chitwan">
                                                <option value="Makwanpur">
                                                <option value="Parsa">
                                                <option value="Rautahat">
                                                <option value="Dang Deukhuri">
                                                <option value="Pyuthan">
                                                <option value="Rolpa">
                                                <option value="Rukum">
                                                <option value="Salyan">
                                                <option value="Khotang">
                                                <option value="Okhaldhunga">
                                                <option value="Saptari">
                                                <option value="Siraha">
                                                <option value="Solukhumbu">
                                                <option value="Udayapur">
                                                <option value="Achham">
                                                <option value="Bajhang">
                                                <option value="Bajura">
                                                <option value="Doti">
                                                <option value="Kailali">
                                               
                                             </datalist>
                                             <!-- Data list ends-->
                                          </tr>
                                          <tr>
                                            <td>Issued Date</td>
                                            <td><input type="text" placeholder="YYYY-MM-DD" name="issued_date" id="nepaliDate5"  required /></td>
                                          </tr>
                                          <tr>
                                            <td>Contact No</td>
                                            <td><input type="text" name="contact_no"  required /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>Nominee</td>
                                            <td><input type="text"  name="nominee" /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>Photo</td>
                                            <td><input type="file" name="pic" required /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>&nbsp;</td>
                                            <td><input type="submit" name="add" value="Add" /></td>
                                          </tr>
                                          </table>

                                    </form>
                                    <form method="post" enctype="multipart/form-data">
                                      <table class="table">
                                          <tr>
                                            <td>Upload File</td>
                                            <td><input type="file" name="excel_file" accept=".xls,.xlsx"><input type="submit" name="upload_excel" value="Upload"></td>
                                          </tr>
                                      </table>
                                    </form>
                                    </div>
									
								</section>

							

						</div>
					</div>

				
        <!-- Sidebar -->
         <?php require_once("menuincludes/sidebar.php"); ?>

      </div>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/skel.min.js"></script>
      <script src="assets/js/util.js"></script>
      <!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
      <script src="assets/js/main.js"></script>

  </body>
</html>