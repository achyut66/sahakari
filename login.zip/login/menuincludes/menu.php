<!-- Menu -->
							<?php if(isset($_SESSION['auth'])): ?>
								<nav id="menu">
									<header class="major">
									
										<h2>Menu</h2>

									</header>
									<ul>
									<?php if($_SESSION['auth']==="administrator"): ?>
									<li>
											<span class="opener">Users</span>
									  			<ul>

												<li><a href="users.php">View All</a></li>
												<li><a href="user_add.php">Add User</a></li>
												

												</ul>
                                       </li>
                                      <?php endif; ?>
                                      <?php  if($_SESSION['auth']==="user"): ?>
                                      	<li>
                                      	<span class="opener">Profile</span>
									  			<ul>

												<li><a href="profile.php">View</a></li>
												
												</ul>
                                      	</li>
										<li>
											<span class="opener">Bad Loan</span>
									  			<ul>

												<li><a href="kalosuchi_list.php">View All</a></li>
												<li><a href="kalosuchi_add.php">Add Bad Loan</a></li>
												<li><a href="kalosuchi_search.php">Search Bad Loan</a></li>

												</ul>
                                       </li>
                                        <li>
											<span class="opener">Board Members</span>
									  			<ul>

												<li><a href="boardmembers_list.php">View All</a></li>
												<li><a href="boardmembers_add.php">Add Boardmember</a></li>
												
												
												</ul>
                                       </li> 

                                       <li>
											<span class="opener">Loan Sub Committee</span>
									  			<ul>

												<li><a href="loancom_list.php">View All</a></li>
												<li><a href="loancom_add.php">Add Member</a></li>
												
												
												</ul>
                                       </li> 
                                        <li>
											<span class="opener">Finance Committee</span>
									  			<ul>

												<li><a href="financecom_list.php">View All</a></li>
												<li><a href="financecom_add.php">Add Member</a></li>
												
												
												</ul>
                                       </li>
                                       <li>
											<span class="opener">Loan Memeber</span>
									  			<ul>

												<li><a href="loanmember_list.php">View All</a></li>
												<li><a href="loanmember_add.php">Add Member</a></li>
												
												
												</ul>
                                       </li>   
                                       <?php endif; ?>
                                       
                                       <li><a href="logout.php">Log Out</a></li>
                                          
                                      </ul>
								</nav>

							<?php endif; ?>

							<!-- Section -->