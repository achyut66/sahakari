<!DOCTYPE HTML>
<html>
	<head>
		<title>Sahakari Member Information System</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
        <link href="images/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
        <script type="text/javascript" src="js/jquery.min.js"></script>
         <script type="text/javascript" src="js/frontend.js"></script>
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Main -->
					<div id="main">
						<div class="inner">

							<!-- Header -->
								<header id="header">
									<a href="index.php" class="logo">

									<strong>Sahakari Member Information</strong> Management System !</a>
									<ul class="icons">
										
									</ul>
									<span style="float:right"><?php echo welcomeMsg(); ?>
									<?php if(isset($_SESSION['auth_id']) && $_SESSION['auth']!="administrator"): ?>
										<?php $user = User::find_by_id($_SESSION['auth_id']); ?>
									<br/><strong><?php echo generateRemDays($user->created_date); ?></strong> Days Remaining
								<?php endif; ?>
								</span>
								</header>