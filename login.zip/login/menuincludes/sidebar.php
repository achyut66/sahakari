<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								<div id="irdlogo">
                                	<img src="images/logo.png" alt="SES Logo"><br>
									<h3>Sahakari Member Information System <br>
									</h3>
                                </div>
                                

							<!-- Menu -->
							<?php require_once("menuincludes/menu.php"); ?>

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Get in touch</h2>
									</header>
									<p>For any kind of inquiry please use any of the media listed below.</p>
									<ul class="contact">
										<li class="fa-envelope-o"><a href="mailto:info@bmsnep.com" target="_top">BMS Nepal</a></li>
										<li class="fa-phone">+977-9851117526</li>
										<li class="fa-home">Nagarjun-13, Kalanki <br/>
												Kathmandu, Nepal
										 </li>
									</ul>
								</section>

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; 2017. BMS Nepal. All rights reserved. Developed By: <a href="https://pdmt.com.np" title="Purwanchal Digital Media Technologies Pvt. Ltd." target="_blank">PDMT</a></p>
								</footer>

						</div>
					</div>

			</div>