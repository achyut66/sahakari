<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
   
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  if(isset($_GET['action']))
  {
  	$user_stat = User::find_by_id($_GET['user_id']);
  	if($user_stat->enable==1)
  	{
  		$user_stat->enable = 0;
  		$user_stat->save();
  	}
  	else
  	{
  		$user_stat->enable = 1;
  		$user_stat->save();	
  	}
  }
  $auth_user = User::find_by_id($_SESSION['auth_id']);
  $users = User::find_by_sql('select * from users where mode="user"');
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>User List</h2>
									</header>
                                    <div class="irdform">
                                    	<?php echo $message; ?>
                                    	<table class="table">
                                          
                                         
                                          <tr>
                                         
                                            <td>Org Name</td>
                                             <td>Permanent Address</td>
                                             <td>Email</td>
                                              
                                              <td>Mobile No</td>
                                              <td>Created Date</td>
                                              <td>Action</td>
                                                 
                                          </tr>
                                        <?php foreach($users as $user): ?>
                                        	<?php 
                                              	if($user->enable==1)
                                              	{
                                              		$link = '<a href="users.php?action=changestatus&user_id='.$user->id.'">Disable</a>';
                                              	}
                                              	else
                                              	{
                                              		$link = '<a href="users.php?action=changestatus&user_id='.$user->id.'">Enable</a>';	
                                              	}
                                              ?>
                                            <tr>
                                              
                                              <td><?=$user->org_name ?></td>
                                              
                                              <td><?=$user->address?></td>
                                              <td><?=$user->email?></td>
                                              
                                              <td><?=$user->mobile?></td>
                                             
                                             <td><?=$user->created_date?></td>
                                              <td><?=$link?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </table>

                                    
                                    </div>
									
								</section>

							

						</div>
					</div>

				
				<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								<div id="irdlogo">
                                	
									<h3>Sahakari Easy System<br>
									Nepal</h3>
                                </div>
                               

							<!-- Menu -->
							<?php require_once("menuincludes/menu.php"); ?>

							<!-- Section -->
								
							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; 2017. Blacklist Management Morang. All rights reserved. Developed By: <a href="https://pdmt.com.np" title="Purwanchal Digital Media Technologies Pvt. Ltd." target="_blank">PDMT</a></p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>