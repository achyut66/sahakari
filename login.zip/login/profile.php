<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  
  $user = User::find_by_id($_SESSION['auth_id']);
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
											<h3>Profile <?php if($user->mode!="administrator"): ?><a href="user_edit.php" style="float:right;">Edit</a><?php endif; ?></h3>
											<span><?=$message?></span>
											<table class="table">
												<tr>
													<td>Name:</td>
													<td><?=$user->org_name?></td>
												</tr>
												<tr>
													<td>Address:</td>
													<td><?=$user->address?></td>
												</tr>
												<tr>
													<td>Contact Person:</td>
													<td><?=$user->fullname?></td>
												</tr>
												<tr>
													<td>Contact No:</td>
													<td><?=$user->mobile?> (Mobile) || <?=$user->phone?> (Landline)</td>
												</tr>
												<tr>
													<td>Email(Username):</td>
													<td><?=$user->email?></td>
												</tr>
												<tr>
													<td>Account Created On:</td>
													<td><?=$user->created_date?></td>
												</tr>
											</table>
										</header>
									
										
									</div>
										<span class="image object">
										<?php if(!empty($user->pic_location)){ ?>
										<img src="uploaded/logo/<?=$user->pic_location?>" alt="" />
										<?php }else { ?>
												<img src="uploaded/logo/noimage.png" alt="" />
										<?php } ?>
									</span>
								</section>

							<!-- Section -->
							

						</div>
						
					</div>

				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>
			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>