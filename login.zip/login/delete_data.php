<?php require_once('includes/session.php');
require_once('includes/config.php');
require_once('includes/database.php');
require_once('includes/database_object.php');
require_once('includes/functions.php');
require_once('includes/user.php');
require_once('includes/kalosuchi.php');
require_once('includes/loancom.php');
require_once('includes/financecom.php');
require_once('includes/boardmember.php');
if(!$session->is_logged_in()){ redirect_to("logout.php");}
if(isset($_GET['id']))
{
	$id = $_GET['id'];
	$viewset = $_GET['viewset'];
	//echo $viewset; exit;
	switch ($viewset) {
		case 'boardmember':
			$data = Boardmember::find_by_id($id);
			$link = "uploaded/boardmember/".$data->pic_location;
			$redirect_link = "boardmembers_list.php";
			if($data->uploaded_by != $_SESSION['auth_id'])
			{
				$session->message("Please do not manipulate the url. We will take severe action");
				redirect_to($redirect_link);
			}
			if(file_exists($link))
			{
				unlink($link);
			}
			$data->delete();
			$session->message("Data Deleted Successfully");
			redirect_to($redirect_link);
			break;
		case 'loan':
			$data = Loancom::find_by_id($id);
			$link = "uploaded/loan/".$data->pic_location;
			$redirect_link = "loancom_list.php";
			if($data->uploaded_by != $_SESSION['auth_id'])
			{
				$session->message("Please do not manipulate the url. We will take severe action");
				redirect_to($redirect_link);
			}
			if(file_exists($link))
			{
				unlink($link);
			}
			$data->delete();
			$session->message("Data Deleted Successfully");
			redirect_to($redirect_link);
			break;
		case 'finance':
			$data = Financecom::find_by_id($id);
			$link = "uploaded/finance/".$data->pic_location;
			$redirect_link = "financecom_list.php";
			if($data->uploaded_by != $_SESSION['auth_id'])
			{
				$session->message("Please do not manipulate the url. We will take severe action");
				redirect_to($redirect_link);
			}
			if(file_exists($link))
			{
				unlink($link);
			}
			$data->delete();
			$session->message("Data Deleted Successfully");
			redirect_to($redirect_link);
			break;
		
		default:
			$session->message("something went wrong");
			redirect_to("index.php");
			break;
	}
	
	
}
else
{
	$session->message("No Direct Access");
	redirect_to("index.php");
}
?>