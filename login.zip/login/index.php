<?php
require_once('includes/session.php');
require_once('includes/config.php');
require_once('includes/database.php');
require_once('includes/database_object.php');
require_once('includes/functions.php');
require_once('includes/user.php');
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
											
											<p>Sahakari Member Information System</p>
										</header>
										
										
									</div>
									<span class="image object">
										
									</span>
								</section>

							<!-- Section -->
								

							

						</div>
					</div>

				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>