<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
  require_once("includes/loanmember.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  

  $view = $_GET['view'];
  $loanmember = Loanmember::find_by_id($_GET['id']);

  if($loanmember->uploaded_by != $_SESSION['auth_id'])
  	{ 
  		$session->message('Please do not try to manipulate the url. We will take severe action'); 
  		redirect_to("loanmember_list.php");
  	}
   $user = User::find_by_id($loanmember->uploaded_by);

?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
										<?php if($view==="detail"): ?>
											<h3>Memeber Details of <?=$loanmember->name?></h3><span style="float:right;"><a href="detail_loanmember.php?view=edit&id=<?=$loanmember->id?>">Edit</a></span>
                      <span style="float:left;"><a href="delete_loanmember.php?id=<?=$loanmember->id?>" onclick="return confirm('Are you sure?');">Delete</a></span>
											<table class="table">
                      
												<tr>
													<td>Name:</td>
													<td><?=$loanmember->name?></td>
												</tr>
                        <tr>
													<td>Permanent Address:</td>
													<td><?=$loanmember->address?></td>
												</tr>
                        <tr>
                          <td>Temporary Address:</td>
                          <td><?=$loanmember->temp_address?></td>
                        </tr>
												<tr>
													<td>Contact No:</td>
													<td><?=$loanmember->contact_no?></td>
												</tr>
												<tr>
													<td>Citizenship No:</td>
													<td><?=$loanmember->citizenship_no?></td>
												</tr>
												<tr>
													<td>Issued From:</td>
													<td><?=$loanmember->citizenship_issued_district?></td>
												</tr>
												<tr>
													<td>Issued Date:</td>
													<td><?=$loanmember->issued_date?></td>
												</tr>
												<tr>
													<td>Uploaded By:</td>
													<td><?=$user->fullname?></td>
												</tr>
											</table>

										</header>
									
										
									</div>
									<span class="image object">
										<img src="uploaded/member/<?=$loanmember->pic_location?>" alt="" />
									</span>
								</section>
										<?php endif; ?>

										<?php if($view==="edit"): ?>
											<h3> Member Details of <?=$loanmember->name?></h3>
                      <form method="post" action="add_loanmember.php" enctype="multipart/form-data">
											<table class="table">
                                           <tr>
                                            <td>Name</td>
                                            <td><input type="text" name="name" size="100px" value="<?=$loanmember->name?>" required></td>
                                          </tr>
                                          <tr>
                                            <td>Permanent Address</td>
                                            <td><input type="text" name="address" value="<?=$loanmember->address?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>Temporary Address</td>
                                            <td><input type="text" name="temp_address" value="<?=$loanmember->temp_address?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>Contact Number</td>
                                            <td><input type="text" name="contact_no" value="<?=$loanmember->contact_no?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>CitizenShip Number</td>
                                            <td><input type="text" name="citizenship_no" value="<?=$loanmember->citizenship_no?>" required /></td>
                                          </tr>
                                          <tr>
                                            <td>CitizenShip Issued From</td>
                                            <td><input list="districts" type="text" name="citizenship_issued_district" value="<?=$loanmember->citizenship_issued_district?>"required /></td>
                                            <!-- Data list starts -->
                                              <datalist id="districts">
                                                <option value="Bhaktapur">
                                                <option value="Dhading">
                                                <option value="Kathmandu">
                                                <option value="Kavrepalanchok">
                                                <option value="Lalitpur">
                                                <option value="Nuwakot">
                                                <option value="Rasuwa">
                                                <option value="Sindhupalchok">
                                                <option value="Banke">
                                                <option value="Bardiya">
                                                <option value="Dailekh">
                                                <option value="Jajarkot">
                                                <option value="Surkhet">
                                                <option value="Baglung">
                                                <option value="Mustang">
                                                <option value="Myagdi">
                                                <option value="Parbat">
                                                <option value="Gorkha">
                                                <option value="Kaski">
                                                <option value="Lajung ">
                                                <option value="Manang">
                                                <option value="Syangja">
                                                <option value="Tanahu">
                                                <option value="Dhanusa">
                                                <option value="Dolakha">
                                                <option value="Mahottari">
                                                <option value="Ramechhap">
                                                <option value="Sarlahi">
                                                <option value="Sindhuli">
                                                <option value="Dolpa">
                                                <option value="Humla">
                                                <option value="Jumla">
                                                <option value="Kalikot">
                                                <option value="Mugu">
                                                <option value="Bhojpur">
                                                <option value="Dhankuta">
                                                <option value="Morang">
                                                <option value="Sankhuwasabha">
                                                <option value="Sunsari">
                                                <option value="Terhathum">
                                                <option value="Arghakhanchi">
                                                <option value="Gulmi">
                                                <option value="Kapilvastu">
                                                <option value="Nawalparasi">
                                                <option value="Palpa">
                                                <option value="Rupandehi">
                                                <option value="Baitadi">
                                                <option value="Dadeldhura">
                                                <option value="Darchula">
                                                <option value="Kanchanpur">
                                                <option value="Ilam">
                                                <option value="Jhapa">
                                                <option value="Panchthar">
                                                <option value="Taplejung">
                                                <option value="Bara">
                                                <option value="Chitwan">
                                                <option value="Makwanpur">
                                                <option value="Parsa">
                                                <option value="Rautahat">
                                                <option value="Dang Deukhuri">
                                                <option value="Pyuthan">
                                                <option value="Rolpa">
                                                <option value="Rukum">
                                                <option value="Salyan">
                                                <option value="Khotang">
                                                <option value="Okhaldhunga">
                                                <option value="Saptari">
                                                <option value="Siraha">
                                                <option value="Solukhumbu">
                                                <option value="Udayapur">
                                                <option value="Achham">
                                                <option value="Bajhang">
                                                <option value="Bajura">
                                                <option value="Doti">
                                                <option value="Kailali">
                                               
                                             </datalist>
                                             <!-- Data list ends-->
                                          </tr>
                                          <tr>
                                            <td>Issued Date</td>
                                            <td><input type="text" placeholder="YYYY-MM-DD" name="issued_date" value="<?=$loanmember->issued_date?>" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Change Photo</td>
                                            <td><input type="file" name="pic" /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>&nbsp;</td>
                                            <td><input type="submit" name="edit" value="Update" /></td>
                                            <input type="hidden" name="id" value="<?=$loanmember->id?>" />
                                            
                                           
                                          </tr>
                                        </table>
                                        </form>
										
										</header>
									
										
									</div>
									
								</section>
									<?php endif; ?>
							<!-- Section -->
							

						</div>
						
					</div>

				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>
			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>