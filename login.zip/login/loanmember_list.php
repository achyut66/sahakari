<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
  require_once("includes/loanmember.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  $loanmembers = LoanMember::find_by_uploaded_id($_SESSION['auth_id']);
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Member List</h2>
									</header>
                                    <div class="irdform">
                                    <?php echo $message; ?>
                                    	<table class="table">
                                          
                                         
                                          <tr>
                                          <td></td>
                                            <td>Name</td>
                                             
                                              <td>Permanent Address</td>
                                              <td>Contact Number</td>
                                               <td>CitizenShip Number</td>
                                              <td>&nbsp;</td>
                                                 
                                          </tr>
                                        <?php foreach($loanmembers as $loanmember): ?>
                                            <tr>
                                              <td><img src="uploaded/member/<?=$loanmember->pic_location?>" width="50" height="50"></td>
                                              <td><?=$loanmember->name?></td>
                                              
                                              <td><?=$loanmember->address?></td>
                                              <td><?=$loanmember->contact_no?></td>
                                              <td><?=$loanmember->citizenship_no?></td>
                                              <td><a href="detail_loanmember.php?view=detail&id=<?=$loanmember->id?>">View Details</a></td>
                                              
                                            </tr>
                                        <?php endforeach; ?>
                                        </table>

                                    
                                    </div>
									
								</section>

							

						</div>
					</div>

				
				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>