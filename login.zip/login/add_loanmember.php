<?php require_once('includes/session.php');
require_once('includes/config.php');
require_once('includes/database.php');
require_once('includes/database_object.php');
require_once('includes/functions.php');
require_once('includes/user.php');
require_once('includes/loanmember.php');

if(isset($_POST['add']))
{
	$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
	$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG','bmp','BMP');
	if(in_array($ext,$allowed_ext))
	{
		
		$name = randname($_FILES['pic']['name']);
		
		move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/member/".$name);
	}
	$data = new LoanMember();
	$data->name = $_POST['name'];
	$data->address = $_POST['address'];
	$data->temp_address = $_POST['temp_address'];
	$data->citizenship_no = $_POST['citizenship_no'];
	$data->citizenship_issued_district = $_POST['citizenship_issued_district'];
	$data->issued_date = $_POST['issued_date'];
	$data->contact_no = $_POST['contact_no'];
	$data->nominee = $_POST['nominee'];
	$data->pic_location = $name;
	$data->uploaded_by = $_SESSION['auth_id'];
	if($data->save())
	{
		$session->message("Member Added Successfully");
		redirect_to("loanmember_list.php");
	}
}
if(isset($_POST['edit']))
{
	$data = LoanMember::find_by_id($_POST['id']);
	if(!empty($_FILES['pic']))
	{
		$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
		$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG','bmp','BMP');
		if(in_array($ext,$allowed_ext))
		{
			
			//$name = $kalosuchi->pic_location;
			$new_name = randname($_FILES['pic']['name']);
                        if(file_exists("uploaded/member/".$data->pic_location)){
			unlink("uploaded/member/".$data->pic_location);
			}
			$data->pic_location = $new_name;
			move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/member/".$new_name);
		}
	}
	$data->name = $_POST['name'];
	$data->address = $_POST['address'];
	$data->temp_address = $_POST['temp_address'];
	$data->citizenship_no = $_POST['citizenship_no'];
	$data->citizenship_issued_district = $_POST['citizenship_issued_district'];
	$data->issued_date =$_POST['issued_date'];
	$data->contact_no = $_POST['contact_no'];
	$data->nominee = $_POST['nominee'];
	//$boardmember->uploaded_by = $_SESSION['auth_id'];
	$data->save();
	$session->message("Member Updated Successfully");
	redirect_to("detail_loanmember.php?view=detail&id=".$_POST['id']);
	
}
?>