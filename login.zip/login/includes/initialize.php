<?php

// define core paths
// define them as absolute paths to make sure that require_once works as expected

// directory_seperator is a php pre-defined constant
// (\ for windows, / for unix)
	defined('DS') ? NULL : define('DS','/');
	defined('SITE_ROOT')? NULL : define ('SITE_ROOT','http://pranishshrestha.com.np'.DS.'police1');
	defined ('LIB_PATH') ? NULL : define ('LIB_PATH', SITE_ROOT.DS.'includes');
	// load config file first
	require_once('config.php');
	// load basic functions next so that everything after can use them
	include_once('functions.php');
	// load core objects
	require_once('session.php');
	require_once('database.php');
	require_once('database_object.php');
	
	// load database-related objects
	require_once('user.php');
	require_once('maincat.php');
	require_once('subcat.php');
	require_once('detail.php');
	require_once('comment.php');
	require_once('links.php');
	require_once('pagination.php');
	/*require_once('photograph.php');
	require_once(LIB_PATH.DS.'subject.php');
	require_once(LIB_PATH.DS.'comment.php');
	
	require_once(LIB_PATH.DS.'album.php');*/
	
?>