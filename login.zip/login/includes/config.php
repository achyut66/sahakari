<?php
	defined("DB_SERVER") ? 	NULL : 	define("DB_SERVER", "localhost");
	defined("DB_USER") ? 	NULL : 	define("DB_USER", "bmsnep_sahakari");
	defined("DB_PASS") ? 	NULL : 	define("DB_PASS", "pdmT$$##123");
	defined("DB_NAME") ? 	NULL : 	define("DB_NAME", "bmsnep_sahakari");
?>