<?php
function generateRemDays($created_date){
	$created_timestamp = strtotime($created_date);
	$end_timestamp = $created_timestamp + (365*24*60*60);
	$now = time();
	$diff = $end_timestamp - $now;
	$days = floor($diff/(24*60*60)) + 1;
	return $days;
	
}
function welcomeMsg()
{
	$msg = '';
	if(isset($_SESSION['auth_id']))
	{
		$user = User::find_by_id($_SESSION['auth_id']);
		$msg = "Welcome!! <strong>".$user->org_name."</strong>";
		return $msg;
	}
	return $msg;
	
}
function sendSMS($content)
{
       		
        $ch = curl_init("http://beta.thesmscentral.com/api/v3/sms?" . $content);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res;
}
function generateBlacklistContent($blacklist_id)
{
	$kalosuchi = Kalosuchi::find_by_id($blacklist_id);	
	//print_r($kalosuchi); exit;
	$sender = User::find_by_id($_SESSION['auth_id']);
	
	$content = '';
	$content .= "Blacklist Name: ".$kalosuchi->firstname." ".$kalosuchi->middlename." ".$kalosuchi->lastname."\r\n";
	$content .="Citizenship ID: ".$kalosuchi->citizenship_no."\r\n";
	$content .="Details From:\r\n";
	$content .= "SES Admin\r\n";
	$content .= "Address: ".$sender->address."\r\n";
	$content .= "Contact No: ".$sender->mobile."\r\n";
	
	return $content;
	
}


function convert_date($date){

    $date = explode("-",$date);
    $final_date = '';
    $i=1;
    $count = count($date);
    foreach($date as $datestring)
    {
        if($i==$count){
            $final_date.= convertedNOs($datestring);    
        }
        else{
        $final_date.= convertedNOs($datestring)."/";
        }
        $i++;
    }
    return $final_date;

}
	function convertNos($nos)
{
    $n = '';
  switch($nos){
    case "०": $n = 0; break;
    case "१": $n = 1; break;
    case "२": $n= 2; break;
    case "३": $n = 3; break;
    case "४": $n = 4; break;
    case "५": $n = 5; break;
    case "६": $n = 6; break;
    case "७": $n = 7; break;
    case "८": $n = 8; break;
    case "९": $n = 9; break;
    case "0": $n = "०"; break;
    case "1": $n = "१"; break;
    case "2": $n = "२"; break;
    case "3": $n = "३"; break;
    case "4": $n = "४"; break;
    case "5": $n = "५"; break;
    case "6": $n = "६"; break;
    case "7": $n = "७"; break;
    case "8": $n = "८"; break;
    case "9": $n = "९"; break;
   }
   return $n;
}

 function convertedcit($string)
    {
        	$string = str_split($string);
        	$out = '';
        	foreach($string as $str)
        	{
        		if(is_numeric($str))
        		{
        			$out .= convertNos($str);	
        		}
        		else
        		{
        			$out .=$str;
        		}
        	}
        	return $out;

    }
    function convertedNos($num)
    {
        $str_num = preg_split('//u', ("". $num), -1); // not explode('', ("". $num))

            // For each item in your exploded string, retrieve the Nepali equivalent or vice versa.
            $out = '';
            $out_arr = array_map('convertNos', $str_num);
            $out = implode('', $out_arr);
            return $out;

    }
	function strip_zeros_from_date($marked_string)
	{
		// first remove the marked zeros
		$no_zeros=str_replace('*0','',$marked_string);
		// then remove any remaining marks
		$cleaned_string=str_replace('*','',$no_zeros);
		return $cleaned_string;
	}
	
	function redirect_to($location=NULL)
	{
		if ($location != NULL)
		{
			header ("location:{$location}");
			exit;
		}
	}
	function set_sort()
	{
		if(!isset($_SESSION['sort']))
		{
			$_SESSION['sort'] = 1;
			
			
		}
		if(isset($_GET['sort']))
		{
			if(isset($_GET['sort']) && $_SESSION['sort']==1 )
			{
			
				$_SESSION['sort'] = 2;
				$i=1;
			}
			if(isset($_GET['sort']) && $_SESSION['sort']==2 && $i!=1 )
			{
				
				$_SESSION['sort'] = 1;
				
			}
		}	
		$i='';
	}
	function output_message($message="")
	{
		if (!empty($message))
		{
			return"<p class=\"message\">{$message}</p>";
		}
		else 
		{
			return "";
		}
	}
	function __autoload($class_name)
	{
		$class_name = strtolower($class_name);
		$path = "../includes/{$class_name}.php";
		if (file_exists($path))
		{
			require_once($path);
		}
		else
		{
			die("The file {$class_name}.php could not be found.");
		}
	}
	
	function log_action($action, $message="")
	{
		$logfile = SITE_ROOT.DS.'logs'.DS.'log.txt';
		$new = file_exists($logfile) ? false: true ;
		if ($handle = fopen($logfile, 'a'))//append
		{
			$timestamp = strftime("%Y-%m-%d %H:%M:%S" , time());
			$content = "{$timestamp} | {$action} | {$message}\n";
			fwrite($handle, $content);
			fclose($handle);
			if ($new)
			{
				chmod($logfile, 0755);
			}
			else
			{
				echo "could not open the log file for writing";
			}
		}
	}
	
	function datetime_to_text($datetime="")
	{
		$unixdatetime = strtotime($datetime);
		return strftime("%B %d, %Y at %I:%M %p", $unixdatetime);
	}
	function datetime_to_text_nosec($datetime="")
	{
		$unixdatetime = strtotime($datetime);
		return strftime("%B %d, %Y", $unixdatetime);
	}

	function randname($filename)
	{
		$name = explode(".", $filename);
		$ext_index_count = count($name)-1;
		$extension = $name[$ext_index_count];
		$firstname = $name[$ext_index_count-1].time()*rand();
		$filename = $firstname.'.'.$extension;
		return $filename;
	}

	function mailto($to, $subject, $body)
	{	
		//$body.= '<a href="'.$link.'">Click here to login</a>';
		$headers = "FROM: http://bmsnep.com <sunaulo7526@gmail.com>\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		$mail = mail($to, $subject, $body, $headers);
		return $mail;
	}

	function newRegEmail($username, $password)
	{
		$link ='http://bmsnep.com/login';
		$body = "Username: ".trim($username)."<br/>";
    		$body .= "Password: ".trim($password)."<br/>";
    		$body .= '<a href="'.$link.'">Click here to login</a>';
    		return $body;
	}
	function validateEmail($email) {
      return filter_var($email, FILTER_VALIDATE_EMAIL);
   }

?>