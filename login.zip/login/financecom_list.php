<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
   require_once("includes/financecom.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  $financecoms = Financecom::find_by_uploaded_id($_SESSION['auth_id']);
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Finance Committee Members List</h2>
									</header>
                                    <div class="irdform">
                                    	<?php echo $message; ?>
                                    	<table class="table">
                                          
                                         
                                          <tr>
                                          <td></td>
                                            <td> First Name</td>
                                             <td>Last Name</td>
                                              <td>Permanent Address</td>
                                              <td>Contact Number</td>
                                               <td>Designation</td>
                                              <td>View</td>
                                                <td>Edit</td>
                                                <td>Delete</td>
                                          </tr>
                                        <?php foreach($financecoms as $financecom): ?>
                                            <tr>
                                              <td><img src="uploaded/finance/<?=$financecom->pic_location?>" width="50" height="50"></td>
                                              <td><?=$financecom->firstname." ".$financecom->lastname ?></td>
                                              
                                              <td><?=$financecom->designation?></td>
                                              <td><?=$financecom->address?></td>
                                              <td><?=$financecom->contact_no?></td>
                                              <td><?=$financecom->email?></td>
                                              <td><a href="detail_boardmember.php?view=detail&viewset=finance&id=<?=$financecom->id?>">View Details</a></td>
                                              <td><a href="detail_boardmember.php?view=edit&viewset=finance&id=<?=$financecom->id?>">Edit Details</a></td>
                                              <td><a href="delete_data.php?viewset=finance&id=<?=$financecom->id?>">Delete</a></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </table>

                                    
                                    </div>
									
								</section>

							

						</div>
					</div>

				
				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>