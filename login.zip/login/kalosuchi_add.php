<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  $issued_against="father";
  if(isset($_GET['issued_against']))
  {
    $issued_against = $_GET['issued_against'];
  }
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Add Bad Loan</h2>
									</header>
                                    <div class="irdform">
                                    <span>Citizenship issued Against: 
                                        <form>
                                            <select name="issued_against" onchange="form.submit()">
                                                <option value="father" <?php if($issued_against==="father"){ ?> selected="selected" <?php } ?>>Father</option>
                                                <option value="spouse" <?php if($issued_against==="spouse"){ ?> selected="selected" <?php } ?>>Spouse</option>
                                            </select>
                                       </form>  
                                    <form method="post" action="add_kalosuchi.php" enctype="multipart/form-data">
                                    	<table class="table">
                                         
                                          <tr>
                                            <td>Name</td>
                                            <td><input type="text" name="firstname" placeholder="firstname" size="100px" required><input type="text" size="100px" name="middlename" placeholder="Middle Name" ><input type="text" name="lastname" placeholder="Lastname" size="100px"  required></td>
                                          </tr>
                                          <?php if($issued_against==="father"): ?>
                                          <tr class="issued_father">
                                            <td>Father's Name</td>
                                            <td><input type="text" name="father_name" /></td>
                                          </tr>
                                          <tr class="issued_father">
                                            <td>Grand Father's Name</td>
                                            <td><input type="text" name="grandfather_name" /></td>
                                          </tr>
                                        <?php endif; ?>
                                         <?php if($issued_against==="spouse"): ?>
                                          <tr class="issued_spouse">
                                            <td>Spouse Name</td>
                                            <td><input type="text" name="spouse_name" /></td>
                                          </tr>
                                          <tr class="issued_spouse">
                                            <td>Spouse Father's Name</td>
                                            <td><input type="text" name="spouse_father_name" /></td>
                                          </tr>
                                        <?php endif; ?>
                                          <tr>
                                            <td>Permanent Address</td>
                                            <td><input type="text" name="address" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Temporary Address</td>
                                            <td><input type="text" name="temp_address" /></td>
                                          </tr>
                                          <tr>
                                            <td>Contact Number</td>
                                            <td><input type="text" name="contact_no" required /></td>
                                          </tr>
                                          <tr>
                                            <td>CitizenShip Number</td>
                                            <td><input type="text" name="citizenship_no" required /></td>
                                          </tr>
                                          <tr>
                                            <td>CitizenShip Issued From</td>
                                            <td><input list="districts" type="text" name="citizenship_issued_district" required /></td>
                                            <!-- Data list starts -->
                                              <datalist id="districts">
                                                <option value="Bhaktapur">
                                                <option value="Dhading">
                                                <option value="Kathmandu">
                                                <option value="Kavrepalanchok">
                                                <option value="Lalitpur">
                                                <option value="Nuwakot">
                                                <option value="Rasuwa">
                                                <option value="Sindhupalchok">
                                                <option value="Banke">
                                                <option value="Bardiya">
                                                <option value="Dailekh">
                                                <option value="Jajarkot">
                                                <option value="Surkhet">
                                                <option value="Baglung">
                                                <option value="Mustang">
                                                <option value="Myagdi">
                                                <option value="Parbat">
                                                <option value="Gorkha">
                                                <option value="Kaski">
                                                <option value="Lajung ">
                                                <option value="Manang">
                                                <option value="Syangja">
                                                <option value="Tanahu">
                                                <option value="Dhanusa">
                                                <option value="Dolakha">
                                                <option value="Mahottari">
                                                <option value="Ramechhap">
                                                <option value="Sarlahi">
                                                <option value="Sindhuli">
                                                <option value="Dolpa">
                                                <option value="Humla">
                                                <option value="Jumla">
                                                <option value="Kalikot">
                                                <option value="Mugu">
                                                <option value="Bhojpur">
                                                <option value="Dhankuta">
                                                <option value="Morang">
                                                <option value="Sankhuwasabha">
                                                <option value="Sunsari">
                                                <option value="Terhathum">
                                                <option value="Arghakhanchi">
                                                <option value="Gulmi">
                                                <option value="Kapilvastu">
                                                <option value="Nawalparasi">
                                                <option value="Palpa">
                                                <option value="Rupandehi">
                                                <option value="Baitadi">
                                                <option value="Dadeldhura">
                                                <option value="Darchula">
                                                <option value="Kanchanpur">
                                                <option value="Ilam">
                                                <option value="Jhapa">
                                                <option value="Panchthar">
                                                <option value="Taplejung">
                                                <option value="Bara">
                                                <option value="Chitwan">
                                                <option value="Makwanpur">
                                                <option value="Parsa">
                                                <option value="Rautahat">
                                                <option value="Dang Deukhuri">
                                                <option value="Pyuthan">
                                                <option value="Rolpa">
                                                <option value="Rukum">
                                                <option value="Salyan">
                                                <option value="Khotang">
                                                <option value="Okhaldhunga">
                                                <option value="Saptari">
                                                <option value="Siraha">
                                                <option value="Solukhumbu">
                                                <option value="Udayapur">
                                                <option value="Achham">
                                                <option value="Bajhang">
                                                <option value="Bajura">
                                                <option value="Doti">
                                                <option value="Kailali">
                                               
                                             </datalist>
                                             <!-- Data list ends-->
                                          </tr>
                                          <tr>
                                            <td>Date Of Birth</td>
                                            <td><input type="text" placeholder="YYYY-MM-DD" name="dob" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Photo</td>
                                            <td><input type="file" name="pic" required /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>&nbsp;</td>
                                            <td><input type="submit" name="add" value="Add" /></td>
                                          </tr>
                                          <input type="hidden" name="issued_against" value="<?=$issued_against?>">
                                        </table>

                                    </form>
                                    </div>
									
								</section>

							

						</div>
					</div>

				
        <!-- Sidebar -->
         <?php require_once("menuincludes/sidebar.php"); ?>

      </div>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/skel.min.js"></script>
      <script src="assets/js/util.js"></script>
      <!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
      <script src="assets/js/main.js"></script>

  </body>
</html>