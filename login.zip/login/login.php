<?php
	require_once('includes/session.php');
	require_once('includes/config.php');
	require_once('includes/database.php');
	require_once('includes/database_object.php');
	require_once('includes/functions.php');
	require_once('includes/pagination.php');
	require_once('includes/user.php');
     if($session->is_logged_in()){ redirect_to("index.php");}
            if (isset($_POST['submit']))
            {
                $username =$_POST['username'];
                $password = $_POST['password'];
                if($_POST['type']==1){
                	$found_user = User::authenticate_for_admin($username, $password);
                }else{
                	$found_user = User::authenticate($username, $password);
                }
                if ($found_user)
                {
                    $session->login($found_user);	
                    redirect_to('index.php');
                }
                else
                {
                    $message = "Username or password did not match";		
                }
                
            }
        ?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
								

							<!-- Section -->
								<section>
									
                                    <div class="irdform">
                                    <h2 class="form-signin-heading">Please sign in</h2>
									<span><?=$message?></span>
                                    <form action="<?=htmlentities($_SERVER['PHP_SELF'])?>" method="post">
                                    <table class="table">
			 								<tr>
                                            <td>User Type</td>
                                            <td>
                                            	<select name="type" required>
                                            		<option value="">--Select One--</option>
                                            		<option value="1">Adminitrator</option>
                                            		<option value="2" selected="selected">User</option>
                                            	</select>
                                            </td>
                                          </tr>
                                          <tr>
                                            <td>Username</td>
                                            <td><input type="text" name="username" required></td>
                                          </tr>
                                          <tr>
                                            <td>Password</td>
                                            <td><input type="password" name="password" required /></td>
                                          </tr>
                                          <tr>
                                          	<td>&nbsp;</td>
                                          	<td><input class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="Sign In" /></td>
                                          </tr>
			
			</table>
		  </form>
                                    </div>
									
								</section>

							

						</div>
					</div>

				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>