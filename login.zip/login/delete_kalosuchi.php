<?php require_once('includes/session.php');
require_once('includes/config.php');
require_once('includes/database.php');
require_once('includes/database_object.php');
require_once('includes/functions.php');
require_once('includes/user.php');
require_once('includes/kalosuchi.php');
if(!$session->is_logged_in()){ redirect_to("kalosuchi_list.php");}
if(isset($_GET['id']))
{
	$id = $_GET['id'];
	$kalosuchi = kalosuchi::find_by_id($id);
	if($kalosuchi->delete())
	{

		$session->message("Blacklist Deleted Successfully");
		redirect_to("kalosuchi_list.php");	
	}
	else
	{
		$session->message("Something Went Wrong!! Please contact administrator.");
		redirect_to("kalosuchi_list.php");
	}
	
}
else
{
	$session->message("No Direct Access");
	redirect_to("kalosuchi_list.php");
}
?>