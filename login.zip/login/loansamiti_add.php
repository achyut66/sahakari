<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Add Loan Samiti Members</h2>
									</header>
                                    <div class="irdform">
                                    <form method="post" action="add_kalosuchi.php" enctype="multipart/form-data">
                                    	<table class="table">
                                          
                                         
                                          <tr>
                                            <td>First Name</td>
                                            <td><input type="text" name="name" required></td>
                                          </tr>
                                          <tr>
                                            <td>Last Name</td>
                                            <td><input type="text" name="father_name" /></td>
                                          </tr>
                                        
                                        
                                            <td>Permanent Address</td>
                                            <td><input type="text" name="address" /></td>
                                          </tr>
                                          <tr>
                                            <td>Contact Number</td>
                                            <td><input type="text" name="contact_no" /></td>
                                          </tr>
                                          <tr>
                                            <td>Email Address</td>
                                            <td><input type="text" name="citizenship_no" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Designation</td>
                                            <td><input type="text" name="citizenship_issued_district" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Date Of Birth</td>
                                            <td><input type="text" placeholder="YYYY-MM-DD" name="dob" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Photo</td>
                                            <td><input type="file" name="pic" required /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>&nbsp;</td>
                                            <td><input type="submit" name="add" value="Add" /></td>
                                          </tr>
                                        </table>

                                    </form>
                                    </div>
									
								</section>

							

						</div>
					</div>

				
        <!-- Sidebar -->
          <div id="sidebar">
            <div class="inner">

              <!-- Search -->
                <div id="irdlogo">
                                 
                  <h3>Sahakari Easy System<br>
                  Nepal</h3>
                                </div>
                               

              <!-- Menu -->
              <?php require_once("menuincludes/menu.php"); ?>

              <!-- Section -->
                
              <!-- Footer -->
                <footer id="footer">
                  <p class="copyright">&copy; 2017. Blacklist Management Morang. All rights reserved. Developed By: <a href="https://pdmt.com.np" title="Purwanchal Digital Media Technologies Pvt. Ltd." target="_blank">PDMT</a></p>
                </footer>

            </div>
          </div>

      </div>

    <!-- Scripts -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/skel.min.js"></script>
      <script src="assets/js/util.js"></script>
      <!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
      <script src="assets/js/main.js"></script>

  </body>
</html>