<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  

  $view = $_GET['view'];
  $kalosuchi = Kalosuchi::find_by_id($_GET['id']);
  if(isset($_GET['issued_against']))
  {
    $issued_against = $_GET['issued_against'];
  }
  elseif(!isset($_GET['issued_against']) && !empty($kalosuchi->issued_against))
  {
    $issued_against = $kalosuchi->issued_against;
  }
  else
  {
    $issued_against ="father";
  }
  if(empty($kalosuchi->issued_against)){$kalosuchi->issued_against="father";}
  if($kalosuchi->uploaded_by != $_SESSION['auth_id'])
  	{ 
  		$session->message('Please do not try to manipulate the url. We will take severe action'); 
  		redirect_to("kalosuchi_list.php");
  	}
   $user = User::find_by_id($kalosuchi->uploaded_by);

?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
										<?php if($view==="detail"): ?>
											<h3>Blacklist Details of <?=$kalosuchi->firstname." ".$kalosuchi->middlename." ".$kalosuchi->lastname?></h3><span style="float:right;"><a href="detail.php?view=edit&id=<?=$kalosuchi->id?>">Edit</a></span>
                      <span style="float:left;"><a href="delete_kalosuchi.php?id=<?=$kalosuchi->id?>" onclick="return confirm('Are you sure?');">Delete</a></span>
											<table class="table">
                      
												<tr>
													<td>Name:</td>
													<td><?=$kalosuchi->firstname." ".$kalosuchi->middlename." ".$kalosuchi->lastname?></td>
												</tr>
                        <?php if($issued_against==="father" || empty($kalosuchi->issued_against)){?>
                        <tr>
                          <td>father Name:</td>
                          <td><?=$kalosuchi->father_name?></td>
                        </tr>
												<tr>
													<td>Grandfather Name:</td>
													<td><?=$kalosuchi->grandfather_name?></td>
												</tr>
                        <?php }else{ ?>
                          <tr>
                          <td>Spouse Name:</td>
                          <td><?=$kalosuchi->spouse_name?></td>
                        </tr>
                        <tr>
                          <td>Spouse Father's Name:</td>
                          <td><?=$kalosuchi->spouse_father_name?></td>
                        </tr>
                        <?php } ?>
												<tr>
													<td>Permanent Address:</td>
													<td><?=$kalosuchi->address?></td>
												</tr>
                        <tr>
                          <td>Temporary Address:</td>
                          <td><?=$kalosuchi->temp_address?></td>
                        </tr>
												<tr>
													<td>Contact No:</td>
													<td><?=$kalosuchi->contact_no?></td>
												</tr>
												<tr>
													<td>Citizenship No:</td>
													<td><?=$kalosuchi->citizenship_no?></td>
												</tr>
												<tr>
													<td>Issued From:</td>
													<td><?=$kalosuchi->citizenship_issued_district?></td>
												</tr>
												<tr>
													<td>Date of Birth:</td>
													<td><?=$kalosuchi->dob?></td>
												</tr>
												<tr>
													<td>Uploaded By:</td>
													<td><?=$user->fullname?></td>
												</tr>
											</table>

										</header>
									
										
									</div>
									<span class="image object">
										<img src="uploaded/blacklist/<?=$kalosuchi->pic_location?>" alt="" />
									</span>
								</section>
										<?php endif; ?>

										<?php if($view==="edit"): ?>
											<h3>Blacklist Details of <?=$kalosuchi->firstname." ".$kalosuchi->middlename." ".$kalosuchi->lastname?></h3>
                      <form >
                                            <select name="issued_against" onchange="form.submit()">
                                                <option value="father" <?php if($issued_against==="father"){ ?> selected="selected" <?php } ?>>Father</option>
                                                <option value="spouse" <?php if($issued_against==="spouse"){ ?> selected="selected" <?php } ?>>Spouse</option>
                                            </select>
                              <input type="hidden" name="id" value="<?=$_GET['id']?>">
                              <input type="hidden" name="view" value="<?=$view?>">
                                       </form>  
											<form method="post" action="add_kalosuchi.php" enctype="multipart/form-data">
											<table class="table">
                                           <tr>
                                            <td>Name</td>
                                            <td><input type="text" name="firstname" placeholder="firstname" size="100px" value="<?=$kalosuchi->firstname?>" required><input type="text" size="100px" name="middlename" placeholder="Middle Name" value="<?=$kalosuchi->middlename?>" ><input type="text" name="lastname" placeholder="Lastname" value="<?=$kalosuchi->lastname?>" size="100px"  required></td>
                                          </tr>
                                          <?php if($issued_against==="father"){?>
                                          <tr>
                                            <td>Father's Name</td>
                                            <td><input type="text" name="father_name" value="<?=$kalosuchi->father_name?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>Grand Father's Name</td>
                                            <td><input type="text" name="grandfather_name" value="<?=$kalosuchi->grandfather_name?>" /></td>
                                          </tr>
                                          <?php } else { ?>
                                            <tr>
                                            <td>Spouse Name</td>
                                            <td><input type="text" name="spouse_name" value="<?=$kalosuchi->spouse_name?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>Spouse Father's Name</td>
                                            <td><input type="text" name="spouse_father_name" value="<?=$kalosuchi->spouse_father_name?>" /></td>
                                          </tr>
                                          <?php } ?>
                                          <tr>
                                            <td>Permanent Address</td>
                                            <td><input type="text" name="address" value="<?=$kalosuchi->address?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>Temporary Address</td>
                                            <td><input type="text" name="temp_address" value="<?=$kalosuchi->temp_address?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>Contact Number</td>
                                            <td><input type="text" name="contact_no" value="<?=$kalosuchi->contact_no?>" /></td>
                                          </tr>
                                          <tr>
                                            <td>CitizenShip Number</td>
                                            <td><input type="text" name="citizenship_no" value="<?=$kalosuchi->citizenship_no?>" required /></td>
                                          </tr>
                                          <tr>
                                            <td>CitizenShip Issued From</td>
                                            <td><input list="districts" type="text" name="citizenship_issued_district" value="<?=$kalosuchi->citizenship_issued_district?>"required /></td>
                                            <!-- Data list starts -->
                                              <datalist id="districts">
                                                <option value="Bhaktapur">
                                                <option value="Dhading">
                                                <option value="Kathmandu">
                                                <option value="Kavrepalanchok">
                                                <option value="Lalitpur">
                                                <option value="Nuwakot">
                                                <option value="Rasuwa">
                                                <option value="Sindhupalchok">
                                                <option value="Banke">
                                                <option value="Bardiya">
                                                <option value="Dailekh">
                                                <option value="Jajarkot">
                                                <option value="Surkhet">
                                                <option value="Baglung">
                                                <option value="Mustang">
                                                <option value="Myagdi">
                                                <option value="Parbat">
                                                <option value="Gorkha">
                                                <option value="Kaski">
                                                <option value="Lajung ">
                                                <option value="Manang">
                                                <option value="Syangja">
                                                <option value="Tanahu">
                                                <option value="Dhanusa">
                                                <option value="Dolakha">
                                                <option value="Mahottari">
                                                <option value="Ramechhap">
                                                <option value="Sarlahi">
                                                <option value="Sindhuli">
                                                <option value="Dolpa">
                                                <option value="Humla">
                                                <option value="Jumla">
                                                <option value="Kalikot">
                                                <option value="Mugu">
                                                <option value="Bhojpur">
                                                <option value="Dhankuta">
                                                <option value="Morang">
                                                <option value="Sankhuwasabha">
                                                <option value="Sunsari">
                                                <option value="Terhathum">
                                                <option value="Arghakhanchi">
                                                <option value="Gulmi">
                                                <option value="Kapilvastu">
                                                <option value="Nawalparasi">
                                                <option value="Palpa">
                                                <option value="Rupandehi">
                                                <option value="Baitadi">
                                                <option value="Dadeldhura">
                                                <option value="Darchula">
                                                <option value="Kanchanpur">
                                                <option value="Ilam">
                                                <option value="Jhapa">
                                                <option value="Panchthar">
                                                <option value="Taplejung">
                                                <option value="Bara">
                                                <option value="Chitwan">
                                                <option value="Makwanpur">
                                                <option value="Parsa">
                                                <option value="Rautahat">
                                                <option value="Dang Deukhuri">
                                                <option value="Pyuthan">
                                                <option value="Rolpa">
                                                <option value="Rukum">
                                                <option value="Salyan">
                                                <option value="Khotang">
                                                <option value="Okhaldhunga">
                                                <option value="Saptari">
                                                <option value="Siraha">
                                                <option value="Solukhumbu">
                                                <option value="Udayapur">
                                                <option value="Achham">
                                                <option value="Bajhang">
                                                <option value="Bajura">
                                                <option value="Doti">
                                                <option value="Kailali">
                                               
                                             </datalist>
                                             <!-- Data list ends-->
                                          </tr>
                                          <tr>
                                            <td>Date Of Birth</td>
                                            <td><input type="text" placeholder="YYYY-MM-DD" name="dob" value="<?=$kalosuchi->dob?>" required /></td>
                                          </tr>
                                          <tr>
                                            <td>Change Photo</td>
                                            <td><input type="file" name="pic" /></td>
                                          </tr>
                                          
                                          <tr>
                                            <td>&nbsp;</td>
                                            <td><input type="submit" name="edit" value="Update" /></td>
                                            <input type="hidden" name="id" value="<?=$kalosuchi->id?>" />
                                            <input type="hidden" name="issued_against" value="<?=$issued_against?>" />
                                           
                                          </tr>
                                        </table>
                                        </form>
										
										</header>
									
										
									</div>
									
								</section>
									<?php endif; ?>
							<!-- Section -->
							

						</div>
						
					</div>

				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>
			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>