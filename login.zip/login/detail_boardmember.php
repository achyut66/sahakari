<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
  require_once("includes/boardmember.php");
  require_once("includes/loancom.php");
  require_once("includes/financecom.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
 
  $view = $_GET['view'];
  $viewset = $_GET['viewset'];
  switch ($viewset) {
  	case 'boardmember':
  		 $data = Boardmember::find_by_id($_GET['id']);
  		
  		  if($data->uploaded_by!=$_SESSION['auth_id'])
  		  	{ 
  		  		$session->message('Please do not try to manipulate the url. We will take severe action'); 
  		  		redirect_to("boardmembers_list.php");
  		  	}
  		  $user = User::find_by_id($data->uploaded_by);

  		break;
  	case 'loan':
  		 $data = Loancom::find_by_id($_GET['id']);
  		  if($data->uploaded_by!=$_SESSION['auth_id'])
  		  	{ 
  		  		$session->message('Please do not try to manipulate the url. We will take severe action'); 
  		  		redirect_to("loancom_list.php");
  		  	}
  		  $user = User::find_by_id($data->uploaded_by);
  		break;
  		case 'finance':
  		 $data = Financecom::find_by_id($_GET['id']);
  		  if($data->uploaded_by!=$_SESSION['auth_id'])
  		  	{ 
  		  		$session->message('Please do not try to manipulate the url. We will take severe action'); 
  		  		redirect_to("financecom_list.php");
  		  	}
  		  $user = User::find_by_id($data->uploaded_by);
  		break;
  	default:
  			redirect_to("index.php");
  		break;
  }
 
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
							
								<section id="banner">
									<div class="content">
										<header>
											
											<?php if($view=="detail"): // detail view starts ?>
												<h3>Viewing Boardmember Details</h3>
											<table class="table">
												<tr>
													<td>Name:</td>
													<td><?=$data->firstname." ".$data->lastname?></td>
												</tr>
												<tr>
													<td>Designation:</td>
													<td><?=$data->designation?></td>
												</tr>
												<tr>
													<td>Address:</td>
													<td><?=$data->address?></td>
												</tr>
												<tr>
													<td>Contact No:</td>
													<td><?=$data->contact_no?></td>
												</tr>
												<tr>
													<td>Email Address:</td>
													<td><?=$data->email?></td>
												</tr>
												<tr>
													<td>Uploaded By:</td>
													<td><?=$user->fullname?></td>
												</tr>
											</table>
										<?php endif; // detail view ends ?>

										<?php if($view=="edit"): // edit view starts ?>
											<h3>Editing Boardmember Details</h3>
											<form method="post" enctype="multipart/form-data" action="add_boardmember.php">
											<table class="table">
												<tr>
													<td>Firstname:</td>
													<td><input type="text" name="firstname" value="<?=$data->firstname?>" required ></td>
												</tr>
												<tr>
													<td>Lastname:</td>
													<td><input type="text" name="lastname" value="<?=$data->lastname?>" required ></td>
													
												</tr>
												<tr>
													<td>Designation:</td>
													<td><input type="text" name="designation" value="<?=$data->designation?>" required ></td>
													
												</tr>
												<tr>
													<td>Address:</td>
													<td><input type="text" name="address" value="<?=$data->address?>" required ></td>
													
												</tr>
												<tr>
													<td>Contact No:</td>
													<td><input type="text" name="contact_no" value="<?=$data->contact_no?>" ></td>
													
												</tr>
												<tr>
													<td>Email Address :</td>
													<td><input type="text" name="email" value="<?=$data->email?>" ></td>
													
												</tr>
												<tr>
													<td>Uplaod New Image:</td>
													<td><input type="file" name="pic" ></td>
													
												</tr>
												<tr>
													<td>&nbsp;</td>
													<td><input type="submit" name="edit" value="Update" ></td>
													
												</tr>
											</table>
											<input type="hidden" name="id" value="<?=$data->id?>">
											<input type="hidden" name="add_name" value="<?=$viewset?>">
											</form>
										<?php endif; // edit view ends ?>
										</header>
										
										
									</div>

									<span class="image object">
									
										<img src="uploaded/<?=$viewset?>/<?=$data->pic_location?>" alt="" />
									</span>
								</section>

							<!-- Section for detail view ends -->
							
						</div>
					</div>

				<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								<div id="irdlogo">
                                	
									<h3>Blacklist management <br>
									Morang</h3>
                                </div>
                                <section id="search" class="alt">
									<form method="post" action="#">
										<input type="text" name="query" id="query" placeholder="Search" />
									</form>
						  </section>

							<!-- Menu -->
							<?php require_once("menuincludes/menu.php"); ?>

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Get in touch</h2>
									</header>
									<p>For any kind of inquiry please use any of the media listed below.</p>
									<ul class="contact">
										<li class="fa-envelope-o"><a href="#">info@irdmorang.gov.np</a></li>
										<li class="fa-phone">21-500000</li>
										<li class="fa-home">Traffic Chowk<br />
										Biratnagar, Neepal</li>
									</ul>
								</section>

							<!-- Footer -->
								<footer id="footer">
									<p class="copyright">&copy; 2017. IRD Morang. All rights reserved. Developed By: <a href="https://pdmt.com.np" title="Purwanchal Digital Media Technologies Pvt. Ltd." target="_blank">PDMT</a></p>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>