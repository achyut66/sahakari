<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  

 // $view = $_GET['view'];
  $kalosuchi = Kalosuchi::find_by_id($_GET['id']);
  		
  $user = User::find_by_id($kalosuchi->uploaded_by);

?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
								<section id="banner">
									<div class="content">
										<header>
										
											<h3>Blacklist Details of <?=$kalosuchi->firstname." ".$kalosuchi->middlename." ".$kalosuchi->lastname?></h3><span style="float:right;"><a href="kalosuchi_search.php?keyword=<?=$kalosuchi->citizenship_no?>">Go Back</a></span>
											<table class="table">
												<tr>
													<td>Name:</td>
													<td><?=$kalosuchi->firstname." ".$kalosuchi->middlename." ".$kalosuchi->lastname?></td>
												</tr>
                        <tr>
                          <td>father Name:</td>
                          <td><?=$kalosuchi->father_name?></td>
                        </tr>
												<tr>
													<td>Grandfather Name:</td>
													<td><?=$kalosuchi->grandfather_name?></td>
												</tr>
												<tr>
													<td>Address:</td>
													<td><?=$kalosuchi->address?></td>
												</tr>
												<tr>
													<td>Contact No:</td>
													<td><?=$kalosuchi->contact_no?></td>
												</tr>
												<tr>
													<td>Citizenship No:</td>
													<td><?=$kalosuchi->citizenship_no?></td>
												</tr>
												<tr>
													<td>Issued From:</td>
													<td><?=$kalosuchi->citizenship_issued_district?></td>
												</tr>
												<tr>
													<td>Date of Birth:</td>
													<td><?=$kalosuchi->dob?></td>
												</tr>
												</table>
                        <?php if($kalosuchi->uploaded_by != $_SESSION['auth_id']): ?>
                        <a href="send_info.php?id=<?=$kalosuchi->id?>">Send Info</a>
                      <?php endif; ?>
										</header>
									
										
									</div>
									<span class="image object">
										<img src="uploaded/blacklist/<?=$kalosuchi->pic_location?>" alt="" />
									</span>
								</section>
										

										<!-- Section -->
							

						</div>
						
					</div>

				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>
			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>