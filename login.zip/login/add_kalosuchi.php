<?php require_once('includes/session.php');
require_once('includes/config.php');
require_once('includes/database.php');
require_once('includes/database_object.php');
require_once('includes/functions.php');
require_once('includes/user.php');
require_once('includes/kalosuchi.php');

if(isset($_POST['add']))
{
	$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
	$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG','bmp','BMP');
	if(in_array($ext,$allowed_ext))
	{
		
		$name = randname($_FILES['pic']['name']);
		
		move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/blacklist/".$name);
	}
	$kalosuchi = new Kalosuchi();
	$kalosuchi->firstname = $_POST['firstname'];
	$kalosuchi->middlename = $_POST['middlename'];
	$kalosuchi->lastname = $_POST['lastname'];
	if($_POST['issued_against']==="father")
	{
		$kalosuchi->father_name = $_POST['father_name'];
		$kalosuchi->grandfather_name = $_POST['grandfather_name'];
		$kalosuchi->issued_against = $_POST['issued_against'];
	}
	else
	{
		$kalosuchi->spouse_name = $_POST['spouse_name'];
		$kalosuchi->spouse_father_name = $_POST['spouse_father_name'];
		$kalosuchi->issued_against = $_POST['issued_against'];
	}
	$kalosuchi->address = $_POST['address'];
	$kalosuchi->temp_address = $_POST['temp_address'];
	$kalosuchi->contact_no = $_POST['contact_no'];
	$kalosuchi->citizenship_no = $_POST['citizenship_no'];
	$kalosuchi->citizenship_issued_district = $_POST['citizenship_issued_district'];
	$kalosuchi->dob = $_POST['dob'];
	$kalosuchi->pic_location = $name;
	$kalosuchi->uploaded_by = $_SESSION['auth_id'];
	if($kalosuchi->save())
	{
		$session->message("Record Added Successfully");
		redirect_to("kalosuchi_list.php");
	}
}
if(isset($_POST['edit']))
{
	$kalosuchi = Kalosuchi::find_by_id($_POST['id']);
	if(!empty($_FILES['pic']))
	{
		$ext = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
		$allowed_ext = array('jpg','JPG','jpeg','JPEG','png','PNG','bmp','BMP');
		if(in_array($ext,$allowed_ext))
		{
			
			//$name = $kalosuchi->pic_location;
			$new_name = randname($_FILES['pic']['name']);
                        if(file_exists("uploaded/blacklist/".$kalosuchi->pic_location)){
			unlink("uploaded/blacklist/".$kalosuchi->pic_location);
			}
			$kalosuchi->pic_location = $new_name;
			move_uploaded_file($_FILES['pic']['tmp_name'], "uploaded/blacklist/".$new_name);
		}
	}
	$kalosuchi->firstname = $_POST['firstname'];
	$kalosuchi->middlename = $_POST['middlename'];
	$kalosuchi->lastname = $_POST['lastname'];
	if($_POST['issued_against']==="father")
	{
		$kalosuchi->father_name = $_POST['father_name'];
		$kalosuchi->grandfather_name = $_POST['grandfather_name'];
		$kalosuchi->issued_against = "father";
	}
	else
	{
		$kalosuchi->spouse_name = $_POST['spouse_name'];
		$kalosuchi->spouse_father_name = $_POST['spouse_father_name'];
		$kalosuchi->issued_against = "spouse";
	}
	$kalosuchi->father_name = $_POST['father_name'];
	$kalosuchi->grandfather_name = $_POST['grandfather_name'];
	$kalosuchi->address = $_POST['address'];
	$kalosuchi->temp_address = $_POST['temp_address'];
	$kalosuchi->contact_no = $_POST['contact_no'];
	$kalosuchi->citizenship_no = $_POST['citizenship_no'];
	$kalosuchi->citizenship_issued_district = $_POST['citizenship_issued_district'];
	$kalosuchi->dob = $_POST['dob'];
	//$boardmember->uploaded_by = $_SESSION['auth_id'];
	$kalosuchi->save();
	$session->message("Record Updated Successfully");
	redirect_to("kalosuchi_list.php");
	
}
?>