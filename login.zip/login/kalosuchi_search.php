<?php 
  require_once("includes/session.php");
  require_once("includes/database.php");
  require_once("includes/functions.php");
  require_once("includes/pagination.php");
  require_once("includes/user.php");
  require_once("includes/kalosuchi.php");
?>
<?php
  if(!$session->is_logged_in()){ redirect_to("logout.php");}
  
  if(isset($_POST['search'])){
 
  $type = $_POST['type'];
  $kalosuchis = Kalosuchi::find_by_citizenship_id($_POST['citizenship_no']);
}
if(isset($_GET['keyword']))
{
	$kalosuchis = Kalosuchi::find_by_citizenship_id($_GET['keyword']);	
}
?>
<?php require_once "menuincludes/header.php"; ?>

							<!-- Banner -->
					

							<!-- Section -->
								<section>
									<header class="major">
										<h2>Search Bad Loan</h2>
									</header>
									<div>
											
											<form method="post" action="kalosuchi_search.php">
											<select name="type">
													<option value="">Select Type</option>
													<option value="citizenship_no">Citizenship ID</option>

											</select>
											<input type="text" name="citizenship_no" placeholder="Search" />
											<input type="submit" name="search" value="Search">
											</form>
									</div>
									<div>
										
											<?=$message?>
									</div>
									<?php if(!empty($kalosuchis)){ ?>
                                    <div class="irdform">
                                    
                                    	<table class="table">
                                          
                                         
                                          <tr>
                                          <td></td>
                                            <td>Name</td>
                                             
                                              <td>Permanent Address</td>
                                              <td>Contact Number</td>
                                               <td>CitizenShip Number</td>
                                              <td>&nbsp;</td>
                                               <td>&nbsp;</td>
                                          </tr>
                                        	<?php foreach($kalosuchis as $kalosuchi): ?>
                                            <tr>
                                              <td><img src="uploaded/blacklist/<?=$kalosuchi->pic_location?>" width="50" height="50"></td>
                                              <td><?=$kalosuchi->firstname?></td>
                                              
                                              <td><?=$kalosuchi->address?></td>
                                              <td><?=$kalosuchi->contact_no?></td>
                                              <td><?=$kalosuchi->citizenship_no?></td>
                                              <td><a href="detail_search.php?id=<?=$kalosuchi->id?>&keyword=<?=$kalosuchi->citizenship_no?>">View Details</a></td>
                                              <td>
                                              <?php if($kalosuchi->uploaded_by==$_SESSION['auth_id']){ ?>
                                             	Added By You
                                              <?php }else{ ?>
                                              	 <a href="send_info.php?keyword=<?=$kalosuchi->citizenship_no?>&id=<?=$kalosuchi->id?>">Send Info</a>
                                              <?php } ?>
                                              </td>
                                              
                                            </tr>
                                       <?php endforeach; ?>
                                        </table>

                                    
                                    </div>
									<?php } ?>
									<?php if(isset($kalosuchis) && empty($kalosuchis)): ?>
										<h2>Not Found In The Database</h2>
									<?php endif; ?>
									
								</section>

							

						</div>
					</div>

				<!-- Sidebar -->
					<?php require_once("menuincludes/sidebar.php"); ?>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>