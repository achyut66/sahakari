<?php require_once('includes/session.php');
require_once('includes/config.php');
require_once('includes/database.php');
require_once('includes/database_object.php');
require_once('includes/functions.php');
require_once('includes/user.php');
require_once('includes/kalosuchi.php');
if(!$session->is_logged_in()){redirect_to("logout.php");}
$id = $_GET['id'];
//$user = User::find_by_id($id);
        
        $kalosuchi = Kalosuchi::find_by_id($id);
        $user = User::find_by_id($kalosuchi->uploaded_by);
       // print_r($kalosuchi); echo "<hr/>"; print_r($user); exit;
        $token = 'bswyNpfLAiwK3jPY412dSFR4DR6Yxp5jIua';
        $to = $user->mobile;
        $sender    = 'SES Nepal';
        $message = generateBlacklistContent($id);
       
        $content =
        '&token='.rawurlencode($token).
        '&to='.rawurlencode($to).
        '&sender='.rawurlencode($sender).
        '&message='.rawurlencode($message);

        $thesmscentral_response = sendSMS($content);
        mailto($user->email, "Blacklist Details", $message);
        $session->message("Party Informed via SMS and Email");
        redirect_to("kalosuchi_search.php?keyword=".$kalosuchi->citizenship_no);
        
?>